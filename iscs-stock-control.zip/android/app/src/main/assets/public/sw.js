/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "808b8cb0976fe7a62009ce76c2d24a8b"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fa99690ae381b9ac19145ff966c365a8"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ab2f249291cf90ca9277787f79d0800b"
  }, {
    "url": "index.html",
    "revision": "fd988f552ee74077bcc55d58f5e3291f"
  }, {
    "url": "icon.svg",
    "revision": "f0f1ab793c9ba729ace8ad3dd350b3a5"
  }, {
    "url": "icon-512.png",
    "revision": "fa99690ae381b9ac19145ff966c365a8"
  }, {
    "url": "icon-192.png",
    "revision": "ab2f249291cf90ca9277787f79d0800b"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "0b0aeb6bafcf0c6961ce64d5a5c38a73"
  }, {
    "url": "assets/workbox-window.prod.es5-BBnX5xw4.js",
    "revision": null
  }, {
    "url": "assets/index-ClKn6Qi2.css",
    "revision": null
  }, {
    "url": "assets/index-BuYNylR5.js",
    "revision": null
  }, {
    "url": "assets/aistudio/image_aa7f48de.png",
    "revision": null
  }, {
    "url": "assets/aistudio/image_3773103f.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "0b0aeb6bafcf0c6961ce64d5a5c38a73"
  }, {
    "url": "icon.svg",
    "revision": "f0f1ab793c9ba729ace8ad3dd350b3a5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "ab2f249291cf90ca9277787f79d0800b"
  }, {
    "url": "pwa-512x512.png",
    "revision": "fa99690ae381b9ac19145ff966c365a8"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "808b8cb0976fe7a62009ce76c2d24a8b"
  }, {
    "url": "manifest.webmanifest",
    "revision": "5a92865b7a2680e9088d32c65fa85f3f"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//]
  }));

}));
